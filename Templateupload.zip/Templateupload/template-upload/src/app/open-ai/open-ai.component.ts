import { Component } from '@angular/core';
import { OpenaiService } from '../openai.service';

@Component({
  selector: 'app-open-ai',
  templateUrl: './open-ai.component.html',
  styleUrl: './open-ai.component.css'
})
export class OpenAiComponent {
  prompt: string = '';
  response: string = '';
  constructor(private openaiService: OpenaiService) {}

  generateResponse(): void {
    if(!this.prompt.trim()) return;

    this.openaiService.generateText(this.prompt).subscribe(
      (data: any) => {
        this.response = data.choices[0].text.trim();
      },
      (error: any) => {
        console.error('Error connectting to Open ai', error)
      }
    );
  }
}
