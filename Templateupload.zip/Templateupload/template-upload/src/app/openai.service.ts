import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OpenaiService {
  private apiUrl = 'https://genai-openai-genaidatainsiders.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-08-01-preview'; //?api-version=2024-08-01-preview
  private apiKey = '7344700e1b3e4bfda810d20743131d26';
  constructor(private http: HttpClient) { }

  generateText(prompt: string): Observable<any> {
    const headers = new HttpHeaders ({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer 7344700e1b3e4bfda810d20743131d26',
      'api_version': '2024-05-13'
    });

    const body = {
      model: 'gpt-4o',
      prompt: prompt,
      max_tokens: 600,
      temperature:0
    };

    return this.http.post(this.apiUrl, body, {headers});
  }
}
