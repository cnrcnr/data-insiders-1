import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { finalize, Subscription } from 'rxjs';
import { BlobServiceClient, ContainerClient } from '@azure/storage-blob';


@Component({
  selector: 'app-template-upload',
  templateUrl: './template-upload.component.html',
  styleUrl: './template-upload.component.css'
})
export class TemplateUploadComponent implements OnInit{
 selectedFile:any = File;
 private blobServiceClient: any = BlobServiceClient;
 private containerClient:any = ContainerClient;
 blobList: string[] = [];
constructor(private http: HttpClient) {
   
}


ngOnInit(): void {
  const accountName = 'datainsiders';
  const accountKey = 'skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ==';
  const containerName = 'data-insiders-1';
  const sastoken = 'sp=racwli&st=2024-11-14T03:54:38Z&se=2024-11-15T11:54:38Z&spr=https&sv=2022-11-02&sr=c&sig=DMxrWvYgu%2BE8OK9UoGmtM8VviMwsY4n7reRowUua9YU%3D';
  this.blobServiceClient = new BlobServiceClient(
    //`https://${accountName}.blob.core.windows.net/?${accountKey}`);
   `https://${accountName}.blob.core.windows.net/?${sastoken}`);
    this.containerClient = this.blobServiceClient.getContainerClient(containerName);
    console.log('this.containerClient', this.containerClient)
this.getBlobList();
}

async getBlobList() {
  for await (const blob of this.containerClient.listBlobsFlat()) {
    this.blobList.push(blob.name);
  }
  console.log(this.blobList)
}


    onFileSelected(event: any) {
      this.selectedFile = event.target.files[0];
    }
  
    uploadFile() {
      const formData = new FormData();
      formData.append('file', this.selectedFile, this.selectedFile.name);
  
      this.http.post('YOUR_API_ENDPOINT', formData)
        .subscribe(res => {
          console.log(res);
        });
    }
}
