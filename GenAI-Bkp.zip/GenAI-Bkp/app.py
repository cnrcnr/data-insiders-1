import streamlit as st
from click import prompt
from openai import AzureOpenAI
import pandas as pd
import json
import csv
import json
import os
import re
import io
import matplotlib.pyplot as plt

import pandas as pd
from azure.storage.blob import BlobServiceClient
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import SearchIndex, SimpleField, SearchableField
from azure.identity import DefaultAzureCredential
from openai import AzureOpenAI
import os
import pandas as pd
from azure.storage.blob import BlobServiceClient
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchFieldDataType,
)
from azure.search.documents.indexes import SearchIndexClient
from azure.core.credentials import AzureKeyCredential

# Azure Blob Storage credentials
blob_key = "skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ=="
connection_string = "DefaultEndpointsProtocol=https;AccountName=datainsiders;AccountKey=skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ==;EndpointSuffix=core.windows.net"
# Azure Blob Storage credentials
blob_service_client = BlobServiceClient.from_connection_string(connection_string)
# container_name = "data-insiders-1"
container_name = "data-insiders-2"

# Azure Form Recognizer credentials
form_recognizer_endpoint = "https://datainsiderdocint.cognitiveservices.azure.com/"
form_recognizer_key = "AJ96WedBo0hWNaWcDHrswVi1GW87kf4iNuO6365Ak8ldWxwSqPXXJQQJ99AKACYeBjFXJ3w3AAALACOG7YFZ"
document_analysis_client = DocumentAnalysisClient(form_recognizer_endpoint, AzureKeyCredential(form_recognizer_key))

# Azure Cognitive Search credentials
search_service_endpoint = "https://datainsideraisearch.search.windows.net"
search_service_key = "n6DLncmv1k4phwccV7UcpJFhiW9uZa1fa6FpndYw65AzSeAP9gIP"
index_name = "documents-index"
search_client = SearchClient(endpoint=search_service_endpoint, index_name=index_name,
                             credential=AzureKeyCredential(search_service_key))

# Azure OpenAI credentials
# openai_endpoint = "https://genai-openai-genaidatainsiders.openai.azure.com/"
openai_endpoint = 'https://genai-openai-genaidatainsiders.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-08-01-preview'
openai_api_key = "7344700e1b3e4bfda810d20743131d26"
# openai_api_version="2024-05-13"
openai_api_version="2024-08-01-preview"
openai_client = AzureOpenAI(azure_endpoint=openai_endpoint, api_key=openai_api_key,
                            api_version=openai_api_version)


def download_blob(blob_service_client, container_name, blob_name, download_file_path):
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    with open(download_file_path, "wb") as download_file:
        download_file.write(blob_client.download_blob().readall())


def list_blobs_in_container(blob_service_client, container_name):
    container_client = blob_service_client.get_container_client(container_name)
    return [blob.name for blob in container_client.list_blobs()]


def extract_data_from_pdf(file_path):
    with open(file_path, "rb") as f:
        poller = document_analysis_client.begin_analyze_document("prebuilt-document", document=f)
        result = poller.result()

    extracted_data = []
    for page in result.pages:
        for line in page.lines:
            extracted_data.append(line.content)

    for table in result.tables:
        table_data = []
        for cell in table.cells:
            table_data.append(cell.content)
        extracted_data.append(table_data)

    return extracted_data


def extract_data_from_excel(file_path):
    extracted_data = []
    xls = pd.ExcelFile(file_path)
    for sheet_name in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name)
        extracted_data.append(df.to_string(index=False))
    return extracted_data


def extract_data_from_file(file_path):
    file_extension = os.path.splitext(file_path)[1].lower()

    if file_extension == ".pdf":
        return extract_data_from_pdf(file_path)
    elif file_extension in [".xls", ".xlsx"]:
        return extract_data_from_excel(file_path)

    elif file_extension == ".csv":
        return extract_data_from_csv(file_path)

    else:
        raise ValueError(f"Unsupported file type: {file_extension}")


def extract_data_from_csv(file_path):
    data = []
    with open(file_path, mode='r', newline='', encoding='utf-8') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            data.append(row)
    return data


def index_data(search_client, documents):
    # Upload documents to the index
    upload_batch = search_client.upload_documents(documents=documents)
    print(f"Upload result: {upload_batch}")


def search_indexed_data(query):
    results = search_client.search(query)
    retrieved_documents = []
    for result in results:
        retrieved_documents.append(result['content'])
    return retrieved_documents

def prompt1_chart(df):
    # Group by Category and Company, and get the max ROE for each group
    max_roe_2022 = df.groupby(['Category', 'Company'])['ROE'].max().reset_index()

    # Create a list of categories and companies for labels
    categories = max_roe_2022['Category'].unique()
    companies = max_roe_2022['Company'].unique()

    # Create a figure and axis
    fig, ax = plt.subplots(figsize=(10, 6))

    # Bar width and positioning
    bar_width = 0.35
    index = range(len(max_roe_2022))

    # Plotting each category and company
    bars = []
    for i, category in enumerate(categories):
        category_data = max_roe_2022[max_roe_2022['Category'] == category]
        bars.append(ax.bar(index, category_data['ROE'], bar_width, label=f'Category {category}'))

    # Set x-axis labels
    ax.set_xticks(index)
    ax.set_xticklabels(max_roe_2022['Company'], rotation=45)

    # Set axis labels and title
    ax.set_xlabel('Company')
    ax.set_ylabel('Max ROE')
    ax.set_title('Max ROE for 2022 by Category and Company')

    # Add a legend
    ax.legend(title='Category')

    # Adjust layout for better spacing
    plt.tight_layout()

    # Show the plot
    #plt.show()
    st.pyplot(plt)

def prompt2_chart(df):
    plt.figure(figsize=(10, 6))
    plt.plot(df['Year'], df['Revenue'], marker='o', color='b', linestyle='-', linewidth=2,
             markersize=6)
    # Add labels and title
    plt.title('Inflation Rate Over the Years', fontsize=16)
    plt.xlabel('Year', fontsize=12)
    plt.ylabel('Inflation Rate (%)', fontsize=12)
    # Optionally, you can add gridlines for better readability
    plt.grid(True)
    # Show the plot
    plt.tight_layout()
    st.pyplot(plt)

def prompt3_chart(df):
    # Create a figure and axis
    fig, ax = plt.subplots(figsize=(10, 6))

    # List of unique categories for plotting
    categories = df['Category'].unique()

    # Plot EPS and Shareholder Equity for each category
    for category in categories:
        # Filter data for each category
        category_data = df[df['Category'] == category]

        # Plot EPS for this category
        ax.plot(category_data['Year'], category_data['EPS'], marker='o', label=f'EPS - Category {category}')
        # Plot Shareholder Equity for this category
        ax.plot(category_data['Year'], category_data['Equity'], marker='x', label=f'Equity - Category {category}',
                linestyle='--')

    # Add labels and title
    ax.set_title('EPS and Shareholder Equity Over the Last 5 Years by Category', fontsize=16)
    ax.set_xlabel('Year', fontsize=12)
    ax.set_ylabel('Value', fontsize=12)
    # Add a legend to distinguish EPS and Equity lines
    ax.legend(title="Category", bbox_to_anchor=(1.05, 1), loc='upper left')
    # Optionally, you can add gridlines for better readability
    ax.grid(True)
    # Adjust layout for better spacing
    plt.tight_layout()
    # Show the plot
    st.pyplot(plt)

def prompt4_chart(df):
    # Create a figure and axis
    fig, ax1 = plt.subplots(figsize=(10, 6))

    # List of unique companies for plotting
    companies = df['Company'].unique()

    # Plot Debt/Equity Ratio and Revenue for each company
    colors = ['b', 'g']  # Colors for Debt/Equity and Revenue

    for i, company in enumerate(companies):
        # Filter data for each company
        company_data = df[df['Company'] == company]

        # Plot Debt/Equity Ratio on primary y-axis
        ax1.plot(company_data['Year'], company_data['Debt/Equity Ratio'], marker='o', color=colors[0],
                 label=f'Debt/Equity - Company {company}' if i == 0 else "")
        # Plot Revenue on secondary y-axis
        ax2 = ax1.twinx()  # Create a second y-axis
        ax2.plot(company_data['Year'], company_data['Revenue'], marker='x', color=colors[1],
                 label=f'Revenue - Company {company}' if i == 0 else "")

    # Add labels and title
    ax1.set_title('Debt/Equity Ratio and Revenue Over the Years by Company and Category', fontsize=16)
    ax1.set_xlabel('Year', fontsize=12)
    ax1.set_ylabel('Debt/Equity Ratio', fontsize=12, color=colors[0])
    ax2.set_ylabel('Revenue ($ Million)', fontsize=12, color=colors[1])

    # Add legends for both axes
    ax1.legend(loc='upper left')
    ax2.legend(loc='upper right')

    # Optionally, you can add gridlines for better readability
    ax1.grid(True)

    # Adjust layout for better spacing
    plt.tight_layout()

    # Show the plot
    plt.show()

def generate_answer(query, documents):
    # Combine the query with the retrieved documents
    # context = "\n".join(documents)
    context = json.dumps(documents, indent=2)
    prompt = f"Context: {context}\n\nQuestion: {query}\n\nAnswer:"

    response = openai_client.chat.completions.create(
        model="gpt-4o",
        # prompt=prompt,
        max_tokens=600,
        messages=[{"role":"user","content":prompt}],
        temperature=0
    )

    answer = response.choices[0].message.content
    return answer



st.title("GenAI Hackathon: Data Insider")
# st.markdown(
#     """
#     <style>
#     .main {
#         background-color: #add8e6;
#     }
#     </style>
#     """,
#     unsafe_allow_html=True,
# )
prompt_list = ["prompt1", "prompt2", "prompt3"]
select_prompt = st.selectbox("Please choose the prompt:", prompt_list)
if select_prompt == "prompt1":
    user_query = "give me the max roe in 2022 for each category in a tabular format?"
elif select_prompt == "prompt2":
    # user_query = "Can you highlight the calculation flow and interaction between all the files?"
    user_query = "Can you give me the 'AAPL' revenue for all years in a tabular format?"
elif select_query == "prompt3":
    user_query = "give me earnings per share and share holder equity for each category for last 5 years"
st.write("Your query is:", user_query)
st.markdown('Please upload your data')
uploaded_file = st.file_uploader("Choose a file", type=["xlsx", "xls", "json", "csv", "pdf"])

# st.markdown('I want to use the data from Azure Blob')
click = st.button("Click to use the data from Azure Blob")
if click:
    with st.spinner("Loading... Please wait..."):
        blob_names = list_blobs_in_container(blob_service_client, container_name)
        all_extracted_data = []

        for blob_name in blob_names:
        # blob_name = blob_names[0]
        # local_file_path = os.path.join(r"C:\Users\MShi\Documents\hackathon_data", blob_name)
            local_file_path = os.path.join(r"C:\Users\MShi\Documents\data_insider_2", blob_name)
            download_blob(blob_service_client, container_name, blob_name, local_file_path)

            extracted_data = extract_data_from_file(local_file_path)
            all_extracted_data.extend(extracted_data)


        # Step 4: Generate answer using retrieved documents
        # answer = generate_answer(user_query, retrieved_documents)
        answer = generate_answer(user_query, all_extracted_data)
        st.write(answer)
        print(f"Answer: {answer}")

        table_pattern = r"(\|.*\|)"

        # Find all table data (assuming it's a Markdown table with `|` symbols)
        table_data = re.search(table_pattern, answer, re.DOTALL)

        # If a table is found, process it
    if table_data:
        # Extract the table string and remove the '|' symbols and leading/trailing spaces
        cleaned_data = '\n'.join(
            [line.strip().replace('|', '').strip() for line in table_data.group(0).split('\n') if line.strip()]
        )

        # Use StringIO to simulate a file-like object for pandas
        data_io = io.StringIO(cleaned_data)

        # Load the cleaned data into a DataFrame
        df = pd.read_csv(data_io, sep=r'\s+', engine='python').dropna(how = 'any')
        # st.write('Here is the dataframe in the response:')
        # st.dataframe(df)
        # Print the DataFrame
        csv = df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download CSV",
            data=csv,
            file_name = f'{select_prompt}.csv',
            mime="text/csv"
        )
        print(df)
        if select_prompt == "prompt1":
            prompt1_chart(df)

        elif select_prompt == "prompt2":
            prompt2_chart(df)

    else:
        print("No table found in the provided text.")
        st.warning("No table found in the provided text.")




