# Azure Blob Storage credentials
blob_key = "skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ=="
connection_string = "DefaultEndpointsProtocol=https;AccountName=datainsiders;AccountKey=skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ==;EndpointSuffix=core.windows.net"
# Azure Blob Storage credentials
blob_service_client = BlobServiceClient.from_connection_string(connection_string)
container_name = "data-insiders-1"