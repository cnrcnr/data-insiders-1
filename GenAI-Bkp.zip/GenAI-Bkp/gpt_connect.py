import os
import pandas as pd
from azure.storage.blob import BlobServiceClient
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import SearchIndex, SimpleField, SearchableField
from azure.identity import DefaultAzureCredential
from openai import AzureOpenAI, api_version


# from azure.ai.openai import OpenAIClient
# from azure.ai.openai import OpenAIClient
from azure.core.credentials import AzureKeyCredential

# Azure OpenAI credentials
openai_endpoint = "https://genai-openai-genaidatainsiders.openai.azure.com/"
openai_api_key = "7344700e1b3e4bfda810d20743131d26"
openai_api_version="0301"

from azure.ai.openai import OpenAIClient
from azure.core.credentials import AzureKeyCredential

openai_endpoint = "<your-azure-openai-endpoint>"
openai_api_key = "<your-azure-api-key>"

# Initialize the OpenAIClient
client = OpenAIClient(
    endpoint=openai_endpoint,
    credential=AzureKeyCredential(openai_api_key)
)
client = AzureOpenAI(azure_endpoint=openai_endpoint, api_key=openai_api_key, api_version=openai_api_version)


# Create the chat completion request using the correct parameters
response = client.chat.completions.create(
    model="gpt-3.5-turbo",  # Specify the model
    messages=[  # The message list to simulate a conversation
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Tell me a joke."}
    ]
)

# Output the result
print(response.choices[0].message["content"])