import csv
import json
import os
import re
import io

import pandas as pd
from azure.storage.blob import BlobServiceClient
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import SearchIndex, SimpleField, SearchableField
from azure.identity import DefaultAzureCredential
from openai import AzureOpenAI
import os
import pandas as pd
from azure.storage.blob import BlobServiceClient
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchFieldDataType,
)
from azure.search.documents.indexes import SearchIndexClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchFieldDataType,
)
# from azure.ai.openai import OpenAIClient

# Azure Blob Storage credentials
blob_key = "skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ=="
connection_string = "DefaultEndpointsProtocol=https;AccountName=datainsiders;AccountKey=skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ==;EndpointSuffix=core.windows.net"
# Azure Blob Storage credentials
blob_service_client = BlobServiceClient.from_connection_string(connection_string)
# container_name = "data-insiders-1"
container_name = "data-insiders-2"

# Azure Form Recognizer credentials
form_recognizer_endpoint = "https://datainsiderdocint.cognitiveservices.azure.com/"
form_recognizer_key = "AJ96WedBo0hWNaWcDHrswVi1GW87kf4iNuO6365Ak8ldWxwSqPXXJQQJ99AKACYeBjFXJ3w3AAALACOG7YFZ"
document_analysis_client = DocumentAnalysisClient(form_recognizer_endpoint, AzureKeyCredential(form_recognizer_key))

# Azure Cognitive Search credentials
search_service_endpoint = "https://datainsideraisearch.search.windows.net"
search_service_key = "n6DLncmv1k4phwccV7UcpJFhiW9uZa1fa6FpndYw65AzSeAP9gIP"
index_name = "documents-index"
search_client = SearchClient(endpoint=search_service_endpoint, index_name=index_name,
                             credential=AzureKeyCredential(search_service_key))

# Azure OpenAI credentials
# openai_endpoint = "https://genai-openai-genaidatainsiders.openai.azure.com/"
openai_endpoint = 'https://genai-openai-genaidatainsiders.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-08-01-preview'
openai_api_key = "7344700e1b3e4bfda810d20743131d26"
# openai_api_version="2024-05-13"
openai_api_version="2024-08-01-preview"
openai_client = AzureOpenAI(azure_endpoint=openai_endpoint, api_key=openai_api_key,
                            api_version=openai_api_version)
# openai_client = AzureOpenAI(azure_endpoint=openai_endpoint, credential=AzureKeyCredential(openai_api_key))

# Define the index schema
# def create_index_if_not_exists():
#     try:
#         # Check if the index exists
#         existing_indexes = index_client.list_indexes()
#         index_names = [index.name for index in existing_indexes]
#
#         if index_name not in index_names:
#             # Define fields for the index
#             fields = [
#                 SimpleField(name="id", type=SearchFieldDataType.String, key=True),
#                 SearchableField(name="content", type=SearchFieldDataType.String),
#                 CollectionField(name="table_data", type=SearchFieldDataType.String),
#                 SearchableField(name="document_type", type=SearchFieldDataType.String),  # Optional, if you have document type
#             ]
#
#             # Create the index with the defined fields
#             index = SearchIndex(name=index_name, fields=fields)
#             index_client.create_index(index)
#             print(f"Index '{index_name}' created successfully!")
#         else:
#             print(f"Index '{index_name}' already exists.")
#
#     except Exception as e:
#         print(f"Error creating index: {e}")

def download_blob(blob_service_client, container_name, blob_name, download_file_path):
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    with open(download_file_path, "wb") as download_file:
        download_file.write(blob_client.download_blob().readall())


def list_blobs_in_container(blob_service_client, container_name):
    container_client = blob_service_client.get_container_client(container_name)
    return [blob.name for blob in container_client.list_blobs()]


def extract_data_from_pdf(file_path):
    with open(file_path, "rb") as f:
        poller = document_analysis_client.begin_analyze_document("prebuilt-document", document=f)
        result = poller.result()

    extracted_data = []
    for page in result.pages:
        for line in page.lines:
            extracted_data.append(line.content)

    for table in result.tables:
        table_data = []
        for cell in table.cells:
            table_data.append(cell.content)
        extracted_data.append(table_data)

    return extracted_data


def extract_data_from_excel(file_path):
    extracted_data = []
    xls = pd.ExcelFile(file_path)
    for sheet_name in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name)
        extracted_data.append(df.to_string(index=False))
    return extracted_data


def extract_data_from_file(file_path):
    file_extension = os.path.splitext(file_path)[1].lower()

    if file_extension == ".pdf":
        return extract_data_from_pdf(file_path)
    elif file_extension in [".xls", ".xlsx"]:
        return extract_data_from_excel(file_path)

    elif file_extension == ".csv":
        return extract_data_from_csv(file_path)

    else:
        raise ValueError(f"Unsupported file type: {file_extension}")


def extract_data_from_csv(file_path):
    data = []
    with open(file_path, mode='r', newline='', encoding='utf-8') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            data.append(row)
    return data


def index_data(search_client, documents):
    # Upload documents to the index
    upload_batch = search_client.upload_documents(documents=documents)
    print(f"Upload result: {upload_batch}")


def search_indexed_data(query):
    results = search_client.search(query)
    retrieved_documents = []
    for result in results:
        retrieved_documents.append(result['content'])
    return retrieved_documents


def generate_answer(query, documents):
    # Combine the query with the retrieved documents
    # context = "\n".join(documents)
    context = json.dumps(documents, indent=2)
    prompt = f"Context: {context}\n\nQuestion: {query}\n\nAnswer:"

    response = openai_client.chat.completions.create(
        model="gpt-4o",
        # prompt=prompt,
        max_tokens=600,
        messages=[{"role":"user","content":prompt}],
        temperature=0
    )

    answer = response.choices[0].message.content
    return answer


def main():
    # Step 1: List blobs and extract data
    blob_names = list_blobs_in_container(blob_service_client, container_name)
    all_extracted_data = []

    for blob_name in blob_names[:5]:
    # blob_name = blob_names[0]
    # local_file_path = os.path.join(r"C:\Users\MShi\Documents\hackathon_data", blob_name)
        local_file_path = os.path.join(r"C:\Users\MShi\Documents\data_insider_2", blob_name)
        download_blob(blob_service_client, container_name, blob_name, local_file_path)

        extracted_data = extract_data_from_file(local_file_path)
        all_extracted_data.extend(extracted_data)

        # Step 2: Index the extracted data
    # documents = [{"content": data} for data in all_extracted_data]
    # index_data(search_client, documents)

    # Step 3: Receive and process user query
    #user_query = "Can you find the max value in each year in 10-year Real Interest Rates file?"  # Replace with actual user query input
    user_query = "give me the max roe in 2022 for each category and company, can you provide the result in chart or pictures to make it visualize?"

    # retrieved_documents = search_indexed_data(user_query)

    # Step 4: Generate answer using retrieved documents
    # answer = generate_answer(user_query, retrieved_documents)
    answer = generate_answer(user_query, all_extracted_data)
    print(f"Answer: {answer}")

    # rows = re.findall(r'\| (.*?)\| ', answer)
    # table = [row.split(" | ") for row in rows]
    # df = pd.DataFrame(table[1:], columns=table[0])

    # Clean the Markdown table (remove the `|` symbols and any extra spaces)
    # cleaned_data = '\n'.join(
    #     [line.strip().replace('|', '').strip() for line in answer.split('\n') if line.strip()]
    # )
    #
    # # Use io.StringIO to simulate a file-like object for pandas
    # data_io = io.StringIO(cleaned_data)
    #
    # # Load it into a DataFrame
    # df = pd.read_csv(data_io, delim_whitespace=True)
    # print(df)
    # print(df)

    table_pattern = r"(\|.*\|)"

    # Find all table data (assuming it's a Markdown table with `|` symbols)
    table_data = re.search(table_pattern, answer, re.DOTALL)

    # If a table is found, process it
    if table_data:
        # Extract the table string and remove the '|' symbols and leading/trailing spaces
        cleaned_data = '\n'.join(
            [line.strip().replace('|', '').strip() for line in table_data.group(0).split('\n') if line.strip()]
        )

        # Use StringIO to simulate a file-like object for pandas
        data_io = io.StringIO(cleaned_data)

        # Load the cleaned data into a DataFrame
        df = pd.read_csv(data_io, sep=r'\s+', engine='python').dropna(how = 'any')

        # Print the DataFrame
        print(df['Inflation Rate (in US)'])
    else:
        print("No table found in the provided text.")



if __name__ == "__main__":
    main()