from azure.storage.blob import BlobServiceClient
import pandas as pd
import fitz
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
# from lxml.xmlschema import connect

blob_key = "skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ=="
connection_string = "DefaultEndpointsProtocol=https;AccountName=datainsiders;AccountKey=skRz0ojUGpJF/0IKChf7PWEYJyw2fOD8/+n0Zekpnd6Z5HRf6Qhvt+Z1tOLSruBX9SEtvk8qSt4S+AStxJ5NRQ==;EndpointSuffix=core.windows.net"
# Azure Blob Storage credentials
blob_service_client = BlobServiceClient.from_connection_string(connection_string)
container_name = "data-insiders-1"


def download_blob(blob_service_client, container_name, blob_name, download_file_path):
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    with open(download_file_path, "wb") as download_file:
        download_file.write(blob_client.download_blob().readall())


def list_blobs_in_container(blob_service_client, container_name):
    container_client = blob_service_client.get_container_client(container_name)
    return [blob.name for blob in container_client.list_blobs()]


# Get list of all blobs in the container
blob_names = list_blobs_in_container(blob_service_client, container_name)



endpoint = "https://<your-form-recognizer-endpoint>.cognitiveservices.azure.com/"
key = "<your-form-recognizer-key>"

document_analysis_client = DocumentAnalysisClient(endpoint, AzureKeyCredential(key))


def extract_data_from_file(file_path):
    with open(file_path, "rb") as f:
        poller = document_analysis_client.begin_analyze_document("prebuilt-document", document=f)
        result = poller.result()

    extracted_data = []
    for page in result.pages:
        for line in page.lines:
            extracted_data.append(line.content)

    for table in result.tables:
        table_data = []
        for cell in table.cells:
            table_data.append(cell.content)
        extracted_data.append(table_data)

    return extracted_data

def extract_text_from_pdf(pdf_bytes):
    text = ""
    pdf_document = fitz.open(pdf_bytes, filetype='pdf')
    for page in pdf_document:
        text += page.getText()
    return text

def extract_text_from_excel(excel_bytes):
    data = pd.read_excel(excel_bytes)
    text = data.to_string()
    return text


if file_name.endswith(".pdf"):
    text = extract_text_from_pdf(download_stream)
if file_name.endswith(".excel"):
    text = extract_text_from_excle(download_stream)







